import React, { useState } from "react";
import { api, setToken } from "../api";
import { LogIn, Eye, EyeOff, Loader2, ClipboardCheck } from "lucide-react";

export function Login({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail]       = useState("admin@local.com");
  const [password, setPassword] = useState("admin123");
  const [error, setError]       = useState<string | null>(null);
  const [loading, setLoading]   = useState(false);
  const [showPw, setShowPw]     = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const r = await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      setToken(r.token);
      onLogin();
    } catch (err: any) {
      setError(err.message || "Credenciais inválidas");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      height: "100vh", width: "100vw",
      display: "flex", overflow: "hidden",
      fontFamily: "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif",
      background: "#f1f5f9",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
        *, *::before, *::after { box-sizing: border-box; }
        .login-input {
          width: 100%; padding: 11px 14px; font-size: 14px;
          border-radius: 9px; border: 1.5px solid #e2e8f0;
          color: #0f172a; font-family: inherit; background: #fff;
          outline: none; transition: border-color 0.15s, box-shadow 0.15s;
        }
        .login-input:focus {
          border-color: #2563eb !important;
          box-shadow: 0 0 0 3px rgba(37,99,235,0.12) !important;
        }
        .login-btn {
          width: 100%; padding: 12px; font-size: 14.5px; font-weight: 700;
          border-radius: 10px; background: #2563eb; color: #fff; border: none;
          cursor: pointer; font-family: inherit;
          transition: background 0.15s, box-shadow 0.15s;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          letter-spacing: -0.01em;
          box-shadow: 0 2px 12px rgba(37,99,235,0.25);
        }
        .login-btn:hover:not(:disabled) { background: #1d4ed8; box-shadow: 0 4px 18px rgba(37,99,235,0.35); }
        .login-btn:disabled { opacity: 0.65; cursor: not-allowed; }
        @keyframes spin { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
      `}</style>

      {/* Left panel */}
      <div style={{
        flex: 1, background: "#111827",
        display: "flex", flexDirection: "column",
        padding: "36px 48px", overflow: "hidden", minWidth: 0,
        position: "relative",
      }}>
        <div style={{
          position: "absolute", inset: 0, opacity: 0.04,
          backgroundImage: "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)",
          backgroundSize: "40px 40px", pointerEvents: "none",
        }} />

        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0, position: "relative" }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: "#2563eb", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <ClipboardCheck size={19} color="#fff" strokeWidth={2.5} />
          </div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 16, color: "#fff", letterSpacing: "-0.03em" }}>CheckSys</div>
            <div style={{ fontSize: 9.5, color: "#60a5fa", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase" }}>PRO</div>
          </div>
        </div>

        {/* Center */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", maxWidth: 440, position: "relative" }}>
          <span style={{
            display: "inline-block", padding: "4px 12px", borderRadius: 99,
            background: "rgba(37,99,235,0.18)", border: "1px solid rgba(37,99,235,0.3)",
            fontSize: 11, fontWeight: 600, color: "#93c5fd", letterSpacing: "0.06em",
            marginBottom: 22, width: "fit-content",
          }}>
            Sistema de Gestão
          </span>

          <h1 style={{ margin: "0 0 16px", fontSize: 42, fontWeight: 800, color: "#fff", letterSpacing: "-0.045em", lineHeight: 1.08 }}>
            Gestão de<br />
            <span style={{ background: "linear-gradient(135deg, #60a5fa, #2563eb)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              Checklists
            </span>
          </h1>

          <p style={{ margin: "0 0 40px", fontSize: 15, color: "#6b7280", lineHeight: 1.7, maxWidth: 340 }}>
            Controle completo de entradas e saídas com rastreabilidade e auditoria em tempo real.
          </p>

          <div style={{ display: "flex", gap: 28 }}>
            {[["100%","Rastreável"],["24/7","Disponível"],["∞","Empresas"]].map(([v, l]) => (
              <div key={l}>
                <div style={{ fontSize: 22, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em" }}>{v}</div>
                <div style={{ fontSize: 11.5, color: "#4b5563", fontWeight: 500, marginTop: 2 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ fontSize: 11, color: "#374151", flexShrink: 0, position: "relative" }}>
          © 2025 CheckSys · Todos os direitos reservados
        </div>
      </div>

      {/* Right panel */}
      <div style={{
        width: 460, flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        padding: "32px 48px", background: "#fff",
        boxShadow: "-4px 0 32px rgba(15,23,42,0.06)",
      }}>
        <div style={{ width: "100%" }}>
          <div style={{ marginBottom: 28 }}>
            <h2 style={{ margin: "0 0 6px", fontSize: 24, fontWeight: 800, color: "#0f172a", letterSpacing: "-0.04em" }}>
              Bem-vindo de volta
            </h2>
            <p style={{ margin: 0, fontSize: 13.5, color: "#94a3b8" }}>
              Entre com suas credenciais para continuar
            </p>
          </div>

          <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#475569", textTransform: "uppercase", letterSpacing: "0.07em" }}>E-mail</label>
              <input className="login-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="seu@email.com" autoComplete="email" />
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#475569", textTransform: "uppercase", letterSpacing: "0.07em" }}>Senha</label>
              <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
                <input
                  className="login-input" type={showPw ? "text" : "password"}
                  value={password} onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••" autoComplete="current-password"
                  style={{ paddingRight: 42 }}
                />
                <button type="button" onClick={() => setShowPw(p => !p)}
                  style={{ position: "absolute", right: 12, background: "none", border: "none", cursor: "pointer", color: "#94a3b8", display: "flex", alignItems: "center", padding: 0, transition: "color 0.12s" }}
                  onMouseOver={e => { e.currentTarget.style.color = "#2563eb"; }}
                  onMouseOut={e => { e.currentTarget.style.color = "#94a3b8"; }}>
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <div style={{ display: "flex", alignItems: "center", gap: 9, background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: 9, padding: "10px 14px" }}>
                <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#ef4444", flexShrink: 0 }} />
                <span style={{ fontSize: 13, color: "#b91c1c", fontWeight: 500 }}>{error}</span>
              </div>
            )}

            <button type="submit" disabled={loading} className="login-btn" style={{ marginTop: 4 }}>
              {loading
                ? <><Loader2 size={16} style={{ animation: "spin 0.8s linear infinite" }} /> Entrando...</>
                : <><LogIn size={16} strokeWidth={2.5} /> Entrar</>}
            </button>
          </form>

          <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "20px 0" }}>
            <div style={{ flex: 1, height: 1, background: "#f1f5f9" }} />
            <span style={{ fontSize: 10.5, color: "#cbd5e1", fontWeight: 700, letterSpacing: "0.06em" }}>ACESSO DEMO</span>
            <div style={{ flex: 1, height: 1, background: "#f1f5f9" }} />
          </div>

          <div style={{ background: "#f8fafc", border: "1.5px solid #e2e8f0", borderRadius: 10, padding: "14px 16px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px 16px" }}>
            {[["E-mail","admin@local.com"],["Senha","admin123"]].map(([l, v]) => (
              <div key={l}>
                <div style={{ fontSize: 10, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 3 }}>{l}</div>
                <code style={{ fontSize: 12.5, fontFamily: "monospace", color: "#334155", fontWeight: 600 }}>{v}</code>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
